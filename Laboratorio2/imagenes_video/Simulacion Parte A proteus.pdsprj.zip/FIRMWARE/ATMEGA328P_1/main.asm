;========================================================
; CONTROL DE MATRIZ DE LEDS 8X8 Y UART
; ATmega328P - F_CPU = 16 MHz
; Ensamblador: AVRASM2 (Proteus / Microchip Studio)
;========================================================

.include "m328Pdef.inc"

;========================================================
; REGISTROS
;========================================================
.def temp      = r16
.def dato      = r17
.def aux       = r18
.def col_idx   = r19
.def modo      = r20
.def velocidad = r21

;========================================================
; CONSTANTES Y SRAM
;========================================================
.equ VEL_INICIAL = 80      ; Ticks para avance de texto (~80ms)
.equ VEL_MIN     = 10      ; Velocidad m�xima (menor retardo)
.equ VEL_MAX     = 200     ; Velocidad m�nima (mayor retardo)
.equ PASO_VEL    = 15
.equ TOTAL_COLS  = 76      ; Columnas totales de la marquesina

.dseg
buffer_matriz: .byte 8     ; Datos a desplegar en las 8 columnas
cnt_vel:       .byte 1     ; Contador de tiempo de velocidad
offset_texto:  .byte 1     ; �ndice del texto marquesina

;========================================================
; VECTORES DE INTERRUPCI�N
;========================================================
.cseg

.org 0x0000
    rjmp RESET

.org 0x0020
    rjmp TIMER0_OVF_ISR    ; Interrupci�n multiplexado de matriz

;========================================================
; INICIALIZACI�N
;========================================================
RESET:
    ; Stack Pointer
    ldi temp, HIGH(RAMEND)
    out SPH, temp
    ldi temp, LOW(RAMEND)
    out SPL, temp

    ; Configuraci�n de puertos
    ; PORTD: PD0(RX), PD1(TX), PD2..PD7 como salidas de Filas 1..6
    ldi temp, 0b11111110
    out DDRD, temp

    ; PORTB: PB0..PB1 (Filas 7..8), PB2..PB3 (Cols 7..8) como salidas
    ldi temp, 0b00001111
    out DDRB, temp

    ; PORTC: PC0..PC5 (Cols 1..6) como salidas
    ldi temp, 0b00111111
    out DDRC, temp

    ; Apagar salidas inicialmente
    ldi temp, 0x00
    out PORTD, temp
    out PORTB, temp
    ldi temp, 0x3F
    out PORTC, temp        ; Columnas en HIGH (Inactivas)

    ; Configurar UART
    rcall uart_init

    ; Configurar Timer0 para Multiplexado (Prescaler 64)
    ldi temp, (1<<CS01)|(1<<CS00)
    out TCCR0B, temp
    ldi temp, (1<<TOIE0)
    sts TIMSK0, temp

    ; Variables iniciales
    ldi modo, 0            ; Modo 0 = Marquesina
    ldi velocidad, VEL_INICIAL
    sts cnt_vel, velocidad
    ldi temp, 0
    sts offset_texto, temp
    ldi col_idx, 0

    ; Cargar primer frame de texto
    rcall actualizar_buffer_texto

    ; Mostrar men� UART
    ldi ZL, LOW(mensaje_inicio<<1)
    ldi ZH, HIGH(mensaje_inicio<<1)
    rcall uart_print

    rcall mostrar_menu

    sei                    ; Habilitar interrupciones globales

;========================================================
; BUCLE PRINCIPAL (UART RX)
;========================================================
MAIN:
    rcall uart_rx          ; Esperar comando serial

    ; Ignorar Saltos de L�nea / Enter
    cpi temp, 13
    breq MAIN
    cpi temp, 10
    breq MAIN

    cpi temp, '1'
    breq CMD_MARQUESINA

    cpi temp, '2'
    breq CMD_FIGURA1

    cpi temp, '3'
    breq CMD_FIGURA2

    cpi temp, '+'
    breq CMD_RAPIDO

    cpi temp, '-'
    breq CMD_LENTO

    rjmp MAIN

;========================================================
; ATENCI�N A COMANDOS
;========================================================
CMD_MARQUESINA:
    cli
    ldi modo, 0
    ldi temp, 0
    sts offset_texto, temp
    rcall actualizar_buffer_texto
    sei

    ldi ZL, LOW(msg_marquesina<<1)
    ldi ZH, HIGH(msg_marquesina<<1)
    rcall uart_print
    rjmp MAIN

CMD_FIGURA1:
    cli
    ldi modo, 1
    rcall cargar_figura1
    sei

    ldi ZL, LOW(msg_figura1<<1)
    ldi ZH, HIGH(msg_figura1<<1)
    rcall uart_print
    rjmp MAIN

CMD_FIGURA2:
    cli
    ldi modo, 2
    rcall cargar_figura2
    sei

    ldi ZL, LOW(msg_figura2<<1)
    ldi ZH, HIGH(msg_figura2<<1)
    rcall uart_print
    rjmp MAIN

CMD_RAPIDO:
    cpi velocidad, VEL_MIN
    breq RAP_FIN
    subi velocidad, PASO_VEL
RAP_FIN:
    ldi ZL, LOW(msg_rapido<<1)
    ldi ZH, HIGH(msg_rapido<<1)
    rcall uart_print
    rjmp MAIN

CMD_LENTO:
    cpi velocidad, VEL_MAX
    breq LEN_FIN
    subi velocidad, -PASO_VEL
LEN_FIN:
    ldi ZL, LOW(msg_lento<<1)
    ldi ZH, HIGH(msg_lento<<1)
    rcall uart_print
    rjmp MAIN

;========================================================
; INTERRUPCI�N TIMER0: MULTIPLEXADO Y DESPLAZAMIENTO
;========================================================
TIMER0_OVF_ISR:
    push temp
    push dato
    push aux
    push r30
    push r31
    in temp, SREG
    push temp

    ; 1. APAGAR COLUMNAS (Evitar sombras)
    ldi temp, 0x3F
    out PORTC, temp
    in aux, PORTB
    ori aux, 0x0C
    out PORTB, aux

    ; 2. ESCRIBIR DATOS EN FILAS DE LA COLUMNA ACTUAL
    ldi ZL, LOW(buffer_matriz)
    ldi ZH, HIGH(buffer_matriz)
    add ZL, col_idx
    clr temp
    adc ZH, temp
    ld dato, Z             ; Cargar byte de la columna

    ; Escribir Bits 0..5 en PD2..PD7
    mov temp, dato
    lsl temp
    lsl temp
    andi temp, 0b11111100
    in aux, PORTD
    andi aux, 0b00000011
    or temp, aux
    out PORTD, temp

    ; Escribir Bits 6..7 en PB0..PB1
    mov temp, dato
    lsr temp
    lsr temp
    lsr temp
    lsr temp
    lsr temp
    lsr temp
    andi temp, 0b00000011
    in aux, PORTB
    andi aux, 0b11111100
    or temp, aux
    out PORTB, temp

    ; 3. ACTIVAR COLUMNA CORRESPONDIENTE (C�todo Activo en LOW)
    cpi col_idx, 6
    brsh COL_PORTB

    ; Columnas 0 a 5 en PORTC
    ldi temp, 1
    mov aux, col_idx
SHIFT_COL:
    cpi aux, 0
    breq COL_READY
    lsl temp
    dec aux
    rjmp SHIFT_COL
COL_READY:
    com temp
    andi temp, 0x3F
    out PORTC, temp
    rjmp NEXT_COL

COL_PORTB:
    ; Columnas 6 y 7 en PB2 y PB3
    in aux, PORTB
    cpi col_idx, 6
    breq ACT_COL6
    andi aux, ~(1<<PB3)    ; Activar Col 7 (PB3 LOW)
    rjmp OUT_COLB
ACT_COL6:
    andi aux, ~(1<<PB2)    ; Activar Col 6 (PB2 LOW)
OUT_COLB:
    out PORTB, aux

NEXT_COL:
    ; Avanzar columna (0..7)
    inc col_idx
    andi col_idx, 0x07

    ; 4. CONTROL DE VELOCIDAD Y DESPLAZAMIENTO (SOLO EN MODO 0)
    cpi modo, 0
    brne ISR_FIN

    lds temp, cnt_vel
    dec temp
    breq MOVER_MARQUESINA
    sts cnt_vel, temp
    rjmp ISR_FIN

MOVER_MARQUESINA:
    sts cnt_vel, velocidad

    ; Avanzar offset de texto
    lds temp, offset_texto
    inc temp
    cpi temp, TOTAL_COLS
    brlo ST_OFF
    ldi temp, 0
ST_OFF:
    sts offset_texto, temp
    rcall actualizar_buffer_texto

ISR_FIN:
    pop temp
    out SREG, temp
    pop r31
    pop r30
    pop aux
    pop dato
    pop temp
    reti

;========================================================
; SUBRUTINAS DE MEMORIA Y BUFFER
;========================================================
actualizar_buffer_texto:
    push ZL
    push ZH
    push r16
    push r17

    lds r17, offset_texto
    ldi r16, 0             ; Contador 0..7

BUCLE_CARGA:
    ldi ZL, LOW(TEXTO_COLUMNAS<<1)
    ldi ZH, HIGH(TEXTO_COLUMNAS<<1)

    mov aux, r17
    add aux, r16

    cpi aux, TOTAL_COLS
    brlo CALC_PTR
    subi aux, TOTAL_COLS

CALC_PTR:
    add ZL, aux
    clr temp
    adc ZH, temp
    lpm dato, Z            ; Leer byte de la Flash

    ; Guardar en SRAM (buffer_matriz + r16)
    ldi ZL, LOW(buffer_matriz)
    ldi ZH, HIGH(buffer_matriz)
    add ZL, r16
    clr temp
    adc ZH, temp
    st Z, dato

    inc r16
    cpi r16, 8
    brne BUCLE_CARGA

    pop r17
    pop r16
    pop ZH
    pop ZL
    ret

cargar_figura1:
    ldi ZL, LOW(FIGURA_CORAZON<<1)
    ldi ZH, HIGH(FIGURA_CORAZON<<1)
    rcall copiar_figura_buffer
    ret

cargar_figura2:
    ldi ZL, LOW(FIGURA_CARITA<<1)
    ldi ZH, HIGH(FIGURA_CARITA<<1)
    rcall copiar_figura_buffer
    ret

copiar_figura_buffer:
    ldi XL, LOW(buffer_matriz)
    ldi XH, HIGH(buffer_matriz)
    ldi temp, 8
BUCLE_FIG:
    lpm dato, Z+
    st X+, dato
    dec temp
    brne BUCLE_FIG
    ret

;========================================================
; RUTINAS UART
;========================================================
uart_init:
    ldi temp, HIGH(103)    ; Baudrate 9600 a 16MHz
    sts UBRR0H, temp
    ldi temp, LOW(103)
    sts UBRR0L, temp

    ldi temp, (1<<UCSZ01)|(1<<UCSZ00)
    sts UCSR0C, temp
    ldi temp, (1<<RXEN0)|(1<<TXEN0)
    sts UCSR0B, temp
    ret

uart_tx:
    lds aux, UCSR0A
    sbrs aux, UDRE0
    rjmp uart_tx
    sts UDR0, temp
    ret

uart_rx:
    lds aux, UCSR0A
    sbrs aux, RXC0
    rjmp uart_rx
    lds temp, UDR0
    ret

uart_print:
    lpm temp, Z+
    cpi temp, 0
    breq UART_PRINT_FIN
    rcall uart_tx
    rjmp uart_print
UART_PRINT_FIN:
    ret

mostrar_menu:
    ldi ZL, LOW(menu_opciones<<1)
    ldi ZH, HIGH(menu_opciones<<1)
    rcall uart_print
    ret

;========================================================
; TEXTOS EN MEMORIA FLASH
;========================================================
mensaje_inicio:
    .db 13,10,"====================================",13,10
    .db "   CONTROL DE MATRIZ DE LEDS 8X8",13,10
    .db "====================================",13,10,0,0

menu_opciones:
    .db "1 = Mensaje Marquesina (HELLO WORLD)",13,10
    .db "2 = Figura 1 (Corazon)",13,10
    .db "3 = Figura 2 (Carita Feliz)",13,10
    .db "+ = Aumentar velocidad",13,10
    .db "- = Disminuir velocidad",13,10
    .db "Seleccione opcion: ",13,10,0,0

msg_marquesina:
    .db 13,10,"Modo Marquesina activado",13,10,0,0
msg_figura1:
    .db 13,10,"Figura 1 (Corazon) seleccionada",13,10,0,0
msg_figura2:
    .db 13,10,"Figura 2 (Carita) seleccionada",13,10,0,0
msg_rapido:
    .db 13,10,"Velocidad aumentada (+)",13,10,0,0
msg_lento:
    .db 13,10,"Velocidad disminuida (-)",13,10,0,0

;========================================================
; PATRONES DE FIGURAS Y FUENTE DE TEXTO
;========================================================

FIGURA_CORAZON:
    .db 0x0C, 0x1E, 0x3E, 0x7C, 0x7C, 0x3E, 0x1E, 0x0C

FIGURA_CARITA:
    .db 0x3C, 0x42, 0xA5, 0x81, 0xA5, 0x99, 0x42, 0x3C

; Stream de columnas para la marquesina "HELLO WORLD"
TEXTO_COLUMNAS:
    ; Espacio inicial (8 columnas)
    .db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    ; H
    .db 0x7F, 0x08, 0x08, 0x08, 0x7F, 0x00
    ; E
    .db 0x7F, 0x49, 0x49, 0x49, 0x41, 0x00
    ; L
    .db 0x7F, 0x40, 0x40, 0x40, 0x40, 0x00
    ; L
    .db 0x7F, 0x40, 0x40, 0x40, 0x40, 0x00
    ; O
    .db 0x3E, 0x41, 0x41, 0x41, 0x3E, 0x00
    ; (Espacio)
    .db 0x00, 0x00, 0x00, 0x00
    ; W
    .db 0x7F, 0x20, 0x10, 0x20, 0x7F, 0x00
    ; O
    .db 0x3E, 0x41, 0x41, 0x41, 0x3E, 0x00
    ; R
    .db 0x7F, 0x09, 0x19, 0x29, 0x46, 0x00
    ; L
    .db 0x7F, 0x40, 0x40, 0x40, 0x40, 0x00
    ; D
    .db 0x7F, 0x41, 0x41, 0x22, 0x1C, 0x00
    ; Espacio final (8 columnas)
    .db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    .db 0x00, 0x00 ; Alineaci�n de palabra