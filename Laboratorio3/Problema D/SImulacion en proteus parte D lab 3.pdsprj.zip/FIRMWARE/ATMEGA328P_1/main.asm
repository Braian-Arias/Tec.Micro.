
; =============================================
; LABORATORIO 3 - PROBLEMA D
; PIANO ELECTRONICO - ATMEGA328P
; ASSEMBLY AVR - PROTEUS
; RELOJ: 16 MHz
; =============================================

; NO agregar .include
; Proteus carga m328Pdef.inc automaticamente

; CONEXIONES:
; LCD RS = PC0
; LCD E  = PC1
; LCD D4 = PC2
; LCD D5 = PC3
; LCD D6 = PC4
; LCD D7 = PC5
; LCD RW = GND
;
; BUZZER MELODIA = PB2
; BUZZER BAJO    = PB3
;
; BOTONES = PD2-PD7, PB0-PB1
; UART RX = PD0
; UART TX = PD1

.def temp = r16
.def dato = r17
.def nota = r18
.def modo = r19
.def cancion = r20
.def comando = r21
.def anterior = r22
.def contador = r23

.cseg
.org 0x0000
    rjmp INICIO

; =============================================
; INICIALIZACION
; =============================================

INICIO:
    ldi temp,HIGH(RAMEND)
    out SPH,temp
    ldi temp,LOW(RAMEND)
    out SPL,temp

    ; Pulsadores PD2-PD7
    ldi temp,0x00
    out DDRD,temp
    ldi temp,0xFC
    out PORTD,temp

    ; PB0 PB1 entradas
    ; PB2 PB3 salidas
    ldi temp,0x0C
    out DDRB,temp

    ldi temp,0x03
    out PORTB,temp

    ; LCD PC0-PC5
    ldi temp,0x3F
    out DDRC,temp

    clr temp
    out PORTC,temp

    ; Variables
    clr modo
    clr cancion
    clr comando

    ldi anterior,255

    ; Inicializar perif�ricos
    rcall UART_INICIO
    rcall LCD_INICIO
    rcall DETENER_SONIDO

    ; Mensaje inicial
    ldi ZH,HIGH(TXT_INICIO*2)
    ldi ZL,LOW(TXT_INICIO*2)
    rcall LCD_TEXTO

    ldi temp,0xC0
    rcall LCD_COMANDO

    ldi ZH,HIGH(TXT_LISTO*2)
    ldi ZL,LOW(TXT_LISTO*2)
    rcall LCD_TEXTO

    ldi contador,100
ESPERA_INICIO:
    rcall RETARDO_10MS
    dec contador
    brne ESPERA_INICIO

    rcall MOSTRAR_PIANO
    rcall UART_MENU

; =============================================
; PROGRAMA PRINCIPAL
; =============================================

PRINCIPAL:
    rcall UART_REVISAR

    tst modo
    breq IR_PIANO

    rcall TOCAR_CANCION
    rjmp PRINCIPAL

IR_PIANO:
    rcall LEER_BOTON

    cp nota,anterior
    breq PRINCIPAL

    mov anterior,nota

    rcall DETENER_SONIDO

    tst nota
    brne PIANO_NOTA

    rcall MOSTRAR_PIANO
    rjmp PRINCIPAL

PIANO_NOTA:
    rcall MOSTRAR_NOTA
    rcall SONIDO_MELODIA
    rjmp PRINCIPAL

; =============================================
; PULSADORES
; =============================================

LEER_BOTON:
    clr nota

    sbis PIND,2
    rjmp BOTON1

    sbis PIND,3
    rjmp BOTON2

    sbis PIND,4
    rjmp BOTON3

    sbis PIND,5
    rjmp BOTON4

    sbis PIND,6
    rjmp BOTON5

    sbis PIND,7
    rjmp BOTON6

    sbis PINB,0
    rjmp BOTON7

    sbis PINB,1
    rjmp BOTON8

    ret

BOTON1:
    ldi nota,1
    ret

BOTON2:
    ldi nota,2
    ret

BOTON3:
    ldi nota,3
    ret

BOTON4:
    ldi nota,4
    ret

BOTON5:
    ldi nota,5
    ret

BOTON6:
    ldi nota,6
    ret

BOTON7:
    ldi nota,7
    ret

BOTON8:
    ldi nota,8
    ret

; =============================================
; SONIDO - TIMER1 - PB2
; =============================================

SONIDO_MELODIA:
    push r24
    push r25
    push ZL
    push ZH

    ; Detener Timer1
    clr temp
    sts TCCR1A,temp
    sts TCCR1B,temp

    ; Nota 0 o 9 = silencio
    tst nota
    breq MELODIA_FIN

    cpi nota,9
    breq MELODIA_FIN

    ; Buscar TOP en tabla
    ldi ZH,HIGH(TABLA_NOTAS*2)
    ldi ZL,LOW(TABLA_NOTAS*2)

    mov temp,nota
    dec temp
    lsl temp

    add ZL,temp
    clr temp
    adc ZH,temp

    lpm r24,Z+
    lpm r25,Z

    ; Reiniciar Timer1
    clr temp
    sts TCNT1H,temp
    sts TCNT1L,temp

    sts OCR1AH,r25
    sts OCR1AL,r24

    sts OCR1BH,r25
    sts OCR1BL,r24

    ; OC1B alterna en cada comparacion
    ldi temp,(1<<COM1B0)
    sts TCCR1A,temp

    ; CTC, prescaler 8
    ldi temp,(1<<WGM12)|(1<<CS11)
    sts TCCR1B,temp

MELODIA_FIN:
    pop ZH
    pop ZL
    pop r25
    pop r24
    ret

; =============================================
; SONIDO - TIMER2 - PB3
; =============================================

SONIDO_BAJO:
    push r24
    push ZL
    push ZH

    clr temp
    sts TCCR2A,temp
    sts TCCR2B,temp

    tst nota
    breq BAJO_FIN

    cpi nota,9
    breq BAJO_FIN

    ldi ZH,HIGH(TABLA_BAJOS*2)
    ldi ZL,LOW(TABLA_BAJOS*2)

    mov temp,nota
    dec temp

    add ZL,temp
    clr temp
    adc ZH,temp

    lpm r24,Z

    clr temp
    sts TCNT2,temp

    sts OCR2A,r24

    ; OC2A alterna en comparacion
    ldi temp,(1<<COM2A0)|(1<<WGM21)
    sts TCCR2A,temp

    ; Prescaler 128
    ldi temp,(1<<CS22)|(1<<CS20)
    sts TCCR2B,temp

BAJO_FIN:
    pop ZH
    pop ZL
    pop r24
    ret

DETENER_SONIDO:
    clr temp

    sts TCCR1A,temp
    sts TCCR1B,temp

    sts TCCR2A,temp
    sts TCCR2B,temp

    cbi PORTB,2
    cbi PORTB,3
    ret

; =============================================
; LCD EN 4 BITS
; =============================================

LCD_INICIO:
    rcall RETARDO_INICIAL

    cbi PORTC,0
    cbi PORTC,1

    ldi temp,0x03
    rcall LCD_NIBBLE
    rcall RETARDO_5MS

    ldi temp,0x03
    rcall LCD_NIBBLE
    rcall RETARDO_5MS

    ldi temp,0x03
    rcall LCD_NIBBLE
    rcall RETARDO_5MS

    ldi temp,0x02
    rcall LCD_NIBBLE
    rcall RETARDO_5MS

    ldi temp,0x28
    rcall LCD_COMANDO

    ldi temp,0x0C
    rcall LCD_COMANDO

    ldi temp,0x06
    rcall LCD_COMANDO

    ldi temp,0x01
    rcall LCD_COMANDO
    ret

LCD_COMANDO:
    cbi PORTC,0
    rcall LCD_BYTE
    ret

LCD_DATO:
    sbi PORTC,0
    rcall LCD_BYTE
    ret

LCD_BYTE:
    push temp

    swap temp
    rcall LCD_NIBBLE

    pop temp
    rcall LCD_NIBBLE

    rcall RETARDO_5MS
    ret

LCD_NIBBLE:
    push temp
    push dato

    in dato,PORTC
    andi dato,0x01

    andi temp,0x0F
    lsl temp
    lsl temp

    or dato,temp
    out PORTC,dato

    sbi PORTC,1
    nop
    nop
    nop
    cbi PORTC,1

    pop dato
    pop temp
    ret

LCD_TEXTO:
    lpm temp,Z+
    tst temp
    breq LCD_TEXTO_FIN

    rcall LCD_DATO
    rjmp LCD_TEXTO

LCD_TEXTO_FIN:
    ret

; =============================================
; MOSTRAR MODO PIANO
; =============================================

MOSTRAR_PIANO:
    push ZL
    push ZH

    ldi temp,0x01
    rcall LCD_COMANDO

    ldi ZH,HIGH(TXT_PIANO*2)
    ldi ZL,LOW(TXT_PIANO*2)
    rcall LCD_TEXTO

    ldi temp,0xC0
    rcall LCD_COMANDO

    ldi ZH,HIGH(TXT_ESPERANDO*2)
    ldi ZL,LOW(TXT_ESPERANDO*2)
    rcall LCD_TEXTO

    pop ZH
    pop ZL
    ret

; =============================================
; MOSTRAR NOTA
; =============================================

MOSTRAR_NOTA:
    push ZL
    push ZH

    ldi temp,0x01
    rcall LCD_COMANDO

    ldi ZH,HIGH(TXT_NOTA*2)
    ldi ZL,LOW(TXT_NOTA*2)
    rcall LCD_TEXTO

    ldi temp,0xC0
    rcall LCD_COMANDO

    ; Nota guardada en r18
    ; Cada nombre ocupa 8 bytes
    ldi ZH,HIGH(NOMBRES_NOTAS*2)
    ldi ZL,LOW(NOMBRES_NOTAS*2)

    mov temp,nota
    dec temp

    ; Multiplicar indice por 8
    lsl temp
    lsl temp
    lsl temp

    add ZL,temp
    clr temp
    adc ZH,temp

    rcall LCD_TEXTO

    pop ZH
    pop ZL
    ret

; =============================================
; UART - 9600 BAUDIOS
; =============================================

UART_INICIO:
    ldi temp,0
    sts UBRR0H,temp

    ldi temp,103
    sts UBRR0L,temp

    ldi temp,(1<<RXEN0)|(1<<TXEN0)
    sts UCSR0B,temp

    ldi temp,(1<<UCSZ01)|(1<<UCSZ00)
    sts UCSR0C,temp
    ret

UART_CHAR:
    push dato

UART_ESPERA:
    lds dato,UCSR0A
    sbrs dato,UDRE0
    rjmp UART_ESPERA

    sts UDR0,temp

    pop dato
    ret

UART_TEXTO:
    lpm temp,Z+
    tst temp
    breq UART_TEXTO_FIN

    rcall UART_CHAR
    rjmp UART_TEXTO

UART_TEXTO_FIN:
    ret

UART_MENU:
    push ZL
    push ZH

    ldi ZH,HIGH(TXT_MENU*2)
    ldi ZL,LOW(TXT_MENU*2)
    rcall UART_TEXTO

    pop ZH
    pop ZL
    ret

; =============================================
; LEER COMANDOS UART
; =============================================

UART_REVISAR:
    lds temp,UCSR0A
    sbrs temp,RXC0
    ret

    lds temp,UDR0

    ; Esperando numero de cancion?
    tst comando
    breq UART_NORMAL

    clr comando

    cpi temp,'1'
    breq SELECCION1

    cpi temp,'2'
    breq SELECCION2

    cpi temp,'3'
    breq SELECCION3

    ret

UART_NORMAL:
    cpi temp,'C'
    breq UART_ESPERA_C

    cpi temp,'c'
    breq UART_ESPERA_C

    cpi temp,'S'
    breq UART_PARAR

    cpi temp,'s'
    breq UART_PARAR

    cpi temp,'P'
    breq UART_PARAR

    cpi temp,'p'
    breq UART_PARAR

    cpi temp,'M'
    breq UART_VER_MENU

    cpi temp,'m'
    breq UART_VER_MENU

    ret

UART_ESPERA_C:
    ldi comando,1
    ret

UART_VER_MENU:
    rcall UART_MENU
    ret

SELECCION1:
    ldi cancion,1
    rjmp INICIAR_CANCION

SELECCION2:
    ldi cancion,2
    rjmp INICIAR_CANCION

SELECCION3:
    ldi cancion,3

INICIAR_CANCION:
    ldi modo,1
    rcall DETENER_SONIDO
    ret

UART_PARAR:
    clr modo
    rcall DETENER_SONIDO
    ldi anterior,255
    ret

; =============================================
; REPRODUCCION DE CANCIONES
; =============================================

TOCAR_CANCION:
    ; Seleccionar tabla
    cpi cancion,1
    breq CARGAR_C1

    cpi cancion,2
    breq CARGAR_C2

    rjmp CARGAR_C3

CARGAR_C1:
    ldi XH,HIGH(CANCION1*2)
    ldi XL,LOW(CANCION1*2)
    rjmp CANCION_INICIO

CARGAR_C2:
    ldi XH,HIGH(CANCION2*2)
    ldi XL,LOW(CANCION2*2)
    rjmp CANCION_INICIO

CARGAR_C3:
    ldi XH,HIGH(CANCION3*2)
    ldi XL,LOW(CANCION3*2)

CANCION_INICIO:
    ldi temp,0x01
    rcall LCD_COMANDO

    ldi ZH,HIGH(TXT_CANCION*2)
    ldi ZL,LOW(TXT_CANCION*2)
    rcall LCD_TEXTO

    ; Mostrar numero de cancion
    mov temp,cancion
    subi temp,-'0'
    rcall LCD_DATO

    ldi temp,0xC0
    rcall LCD_COMANDO

    ldi ZH,HIGH(TXT_REPRO*2)
    ldi ZL,LOW(TXT_REPRO*2)
    rcall LCD_TEXTO

CANCION_LOOP:
    tst modo
    breq CANCION_SALIR

    ; Leer nota y duracion de Flash
    movw ZL,XL

    lpm nota,Z+
    lpm contador,Z+

    movw XL,ZL

    tst nota
    breq CANCION_TERMINAR

    ; Melodia
    rcall SONIDO_MELODIA

    ; Bajo simplificado
    push nota

    cpi cancion,1
    breq BAJO_C1

    cpi cancion,2
    breq BAJO_C2

    ; Cancion 3 - FA
    ldi nota,4
    rjmp BAJO_EJECUTAR

BAJO_C1:
    ; Cancion 1 - DO
    ldi nota,1
    rjmp BAJO_EJECUTAR

BAJO_C2:
    ; Cancion 2 - RE
    ldi nota,2

BAJO_EJECUTAR:
    rcall SONIDO_BAJO
    pop nota

    ; Duracion en unidades de 100 ms
CANCION_DURACION:
    tst contador
    breq CANCION_LOOP

    push contador
    ldi contador,10

CANCION_100MS:
    rcall RETARDO_10MS
    rcall UART_REVISAR

    tst modo
    breq CANCION_INTERRUPCION

    dec contador
    brne CANCION_100MS

    pop contador
    dec contador
    rjmp CANCION_DURACION

CANCION_INTERRUPCION:
    pop contador
    rjmp CANCION_SALIR

CANCION_TERMINAR:
    clr modo

CANCION_SALIR:
    rcall DETENER_SONIDO
    rcall MOSTRAR_PIANO
    ldi anterior,255
    ret

; =============================================
; RETARDOS
; =============================================

RETARDO_5MS:
    push r24
    push r25

    ldi r24,LOW(20000)
    ldi r25,HIGH(20000)

RET5_LOOP:
    sbiw r24,1
    brne RET5_LOOP

    pop r25
    pop r24
    ret

RETARDO_10MS:
    push r24
    push r25

    ldi r24,LOW(40000)
    ldi r25,HIGH(40000)

RET10_LOOP:
    sbiw r24,1
    brne RET10_LOOP

    pop r25
    pop r24
    ret

RETARDO_INICIAL:
    push contador
    ldi contador,20

RET_INI_LOOP:
    rcall RETARDO_10MS
    dec contador
    brne RET_INI_LOOP

    pop contador
    ret

; =============================================
; TABLAS DE FRECUENCIAS
; Timer1: TOP = F_CPU/(16*f)-1
; Timer2: TOP = F_CPU/(256*f)-1
; =============================================

TABLA_NOTAS:
.dw 3816,3401,3029,2864
.dw 2550,2272,2023,1911
.dw 0,3609,3214,2702
.dw 2409,2145,1804,1703

TABLA_BAJOS:
.db 238,212,188,178
.db 158,141,126,118
.db 0,225,200,168
.db 150,133,112,105

; =============================================
; NOMBRES DE LAS NOTAS
; Cada nombre ocupa 8 bytes
; =============================================

NOMBRES_NOTAS:
.db "DO",0,0,0,0,0,0
.db "RE",0,0,0,0,0,0
.db "MI",0,0,0,0,0,0
.db "FA",0,0,0,0,0,0
.db "SOL",0,0,0,0,0
.db "LA",0,0,0,0,0,0
.db "SI",0,0,0,0,0,0
.db "DO5",0,0,0,0,0
.db "MUTE",0,0,0,0
.db "DO#",0,0,0,0,0
.db "RE#",0,0,0,0,0
.db "FA#",0,0,0,0,0
.db "SOL#",0,0,0,0
.db "LA#",0,0,0,0,0
.db "DO#5",0,0,0,0
.db "RE5",0,0,0,0,0

; =============================================
; CANCION 1 - UNDERGROUND THEME
; Nota, duracion
; 1 = 100 ms
; 2 = 200 ms
; =============================================

CANCION1:
.db 8,1,8,1,9,1,6,1,6,1
.db 9,1,14,1,14,1,9,2,9,2
.db 8,1,8,1,9,1,6,1,6,1
.db 9,1,14,1,14,1,9,2,9,2
.db 8,1,8,1,9,1,6,1,6,1
.db 9,1,14,1,14,1,9,2,9,2

.db 8,1,14,1,5,2,11,2
.db 6,2,14,2

.db 11,1,2,1,10,1,1,1,9,1
.db 11,1,2,1,13,1,5,1,9,1
.db 10,1,1,1,12,1,4,1,9,1
.db 3,1,14,1,6,1,13,1

.db 5,1,12,1,4,1,3,1
.db 11,1,2,1,10,1,1,1
.db 12,1,4,1,3,1,11,1
.db 2,1,10,1,1,1,7,1
.db 14,1,6,1,13,1,5,1

.db 11,1,1,1,11,1,1,1
.db 11,1,1,1,11,1,1,2
.db 0,0

; =============================================
; CANCION 2 - MEGALOVANIA
; =============================================

CANCION2:
.db 16,1,16,1,16,2,6,2
.db 9,1,9,1,12,2,9,1
.db 5,2,4,2,2,2

.db 16,1,16,1,16,2,6,2
.db 9,1,9,1,12,2,9,1
.db 5,2,4,2,2,2

.db 16,1,16,1,16,2,6,2
.db 9,1,9,1,12,2,9,1
.db 5,2,4,2,2,2

.db 16,1,16,1,16,2,6,2
.db 9,1,9,1,12,2,9,1
.db 5,2,4,2,2,2

.db 0,0

; =============================================
; CANCION 3 - ANIMALS
; =============================================

CANCION3:
.db 4,2,4,1,4,1,9,2
.db 4,1,4,1,9,2
.db 4,1,4,1,4,1,4,1,9,2

.db 8,2,8,1,8,1,9,2
.db 14,1,14,1,9,2
.db 4,1,4,1,4,1,4,1,9,2

.db 4,2,4,1,4,1,9,2
.db 13,1,13,1,9,2
.db 4,1,4,1,4,1,4,1,9,2

.db 4,2,4,1,4,1,9,2
.db 4,1,4,1,13,1,13,1
.db 12,1,12,1,4,2,9,2

.db 0,0

; =============================================
; MENSAJES LCD
; =============================================

TXT_INICIO:
.db "PIANO Y CANCION",0

TXT_LISTO:
.db "Listo!",0

TXT_PIANO:
.db "MODO PIANO",0

TXT_ESPERANDO:
.db "Esperando...",0

TXT_NOTA:
.db "NOTA:",0

TXT_CANCION:
.db "CANCION ",0

TXT_REPRO:
.db "Reproduciendo",0

; =============================================
; MENU UART
; =============================================

TXT_MENU:
.db 13,10
.db "PIANO ELECTRONICO",13,10
.db "C1 - Cancion 1",13,10
.db "C2 - Cancion 2",13,10
.db "C3 - Cancion 3",13,10
.db "S - Detener",13,10
.db "P - Modo piano",13,10
.db "M - Mostrar menu",13,10,0
